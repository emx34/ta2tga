============================================================
 EPFext v2.0 ULTRA --- *.EPF Archive Extractor & Re-Packer 
 Design & C0de by: EMX / PhRoZeNCReW (1997) - ISTANBUL 2026 
============================================================
Usage:
  EpfArchiveTool -x archive.epf [threads]   Extract to ->\EPF\
  EpfArchiveTool -c archive.epf [threads]   Re-Pack ->\EPF\ -> archive.epf
  EpfArchiveTool -l archive.epf              List archive contents

[threads] is optional; defaults to the number of hardware threads available.
Both -x and -c back up the original archive to <name>.OLD before touching it.
